using System.Text.Json.Nodes;
using FrigoTrack.Common;

// Uso: dotnet run --project Client -- [url] [--count=5] [--interval-ms=2000] [--invalid] [--bypass-validation]
var baseUrl = args.FirstOrDefault(a => a.StartsWith("http")) ?? "http://localhost:5000";
var count = IntArg("--count", 5);
var intervalMs = IntArg("--interval-ms", 2000);
var sendInvalid = args.Contains("--invalid");             // la prima misura del primo sensore ha 99 gradi
var bypass = args.Contains("--bypass-validation");        // salta la validazione client: mostra il rifiuto del server

var schemas = new SchemaStore();

var sensors = new (string Id, string Cargo, double BaseTemp)[]
{
    ("CELLA-BG-007", "pharma", 5.0),
    ("CAMION-MI-012", "food", 3.0),
    ("CELLA-TO-003", "frozen", -20.0),
};

await Task.WhenAll(sensors.Select((s, i) => RunSensor(s.Id, s.Cargo, s.BaseTemp, invalidFirst: i == 0 && sendInvalid)));

int IntArg(string name, int fallback)
{
    var arg = args.FirstOrDefault(a => a.StartsWith(name + "="));
    return arg is null ? fallback : int.Parse(arg[(name.Length + 1)..]);
}

void Log(string sensor, string text) => Console.WriteLine($"[{sensor}] {text}");

async Task RunSensor(string id, string cargo, double baseTemp, bool invalidFirst)
{
    using var http = new HttpClient { BaseAddress = new Uri(baseUrl) };

    // 1) handshake PRIMA di qualsiasi dato
    var channel = await SecureClient.ConnectAsync(http, schemas, validateBeforeSend: !bypass);
    Log(id, $"handshake riuscito, sessione {channel.SessionId}");

    var rnd = new Random();
    var battery = 100;

    for (var i = 1; i <= count; i++)
    {
        var temp = Math.Round(baseTemp + (rnd.NextDouble() - 0.5) * 2, 1);
        if (i % 4 == 0) temp = Math.Round(temp + 7, 1);   // ogni tanto un'escursione termica: genera un allarme
        if (invalidFirst && i == 1) temp = 99;            // valore fuori standard (max 40)
        battery -= rnd.Next(0, 3);

        var measure = new JsonObject
        {
            ["sensor_id"] = id,
            ["timestamp"] = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'"),
            ["cargo_type"] = cargo,
            ["temperature_c"] = temp,
            ["humidity"] = Math.Round(40 + rnd.NextDouble() * 30, 0),
            ["battery"] = battery,
        };

        try
        {
            // 2) valida con lo schema, 3) cifra e invia (lo fa SendAsync)
            var (status, body) = await channel.SendAsync("/api/telemetry", measure, "measure");
            Log(id, $"{temp} C -> HTTP {(int)status} {body?.ToJsonString()}");
        }
        catch (SchemaException ex)
        {
            Log(id, $"{temp} C -> rifiutato dal client, campo {ex.Field}: {ex.Message}");
        }

        await Task.Delay(intervalMs);
    }

    var (rs, rb) = await channel.SendAsync("/api/readings", new JsonObject { ["sensor_id"] = id }, "readings-request");
    Log(id, $"misure salvate sul server: HTTP {(int)rs}, count = {rb?["count"]}");

    var (cs, cb) = await channel.SendAsync("/api/close", new JsonObject { ["action"] = "close" }, "close-request");
    Log(id, $"sessione chiusa: HTTP {(int)cs} {cb?.ToJsonString()}");
}
