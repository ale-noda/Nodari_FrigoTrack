using System.Collections.Concurrent;
using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using FrigoTrack.Common;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

var schemas = new SchemaStore();
var dataDir = app.Configuration["DataDir"] ?? "data";
Directory.CreateDirectory(dataDir);

var sessions = new ConcurrentDictionary<string, Session>();   // una sessione (e una chiave) per client
var fileLock = new object();
var sessionTtl = TimeSpan.FromHours(1);

// intervalli di sicurezza per tipo di merce (gradi C)
var safeRanges = new Dictionary<string, (double Min, double Max)>
{
    ["food"] = (0, 5),
    ["pharma"] = (2, 8),
    ["frozen"] = (-40, -18),
};

// ---------------------------------------------------------------- handshake
app.MapPost("/api/handshake", async (HttpRequest req) =>
{
    JsonNode? body;
    try { body = JsonNode.Parse(await ReadBody(req)); }
    catch (JsonException) { return Plain(400, "/", "JSON non valido"); }

    var bad = schemas.Validate("handshake-request", body);
    if (bad != null) return Plain(400, bad.Field, bad.Message);

    var p = DiffieHellman.FromHex(body!["p"]!.GetValue<string>());
    var g = DiffieHellman.FromHex(body["g"]!.GetValue<string>());
    var clientPublic = DiffieHellman.FromHex(body["A"]!.GetValue<string>());

    // il server accetta solo il gruppo noto: un p scelto dal client potrebbe essere debole
    if (p != DiffieHellman.P || g != DiffieHellman.G)
        return Plain(400, "/p", "Gruppo Diffie-Hellman non supportato (atteso RFC 3526 gruppo 14)");
    if (!DiffieHellman.IsValidPublic(clientPublic, p))
        return Plain(400, "/A", "Chiave pubblica non valida");

    var b = DiffieHellman.GeneratePrivate();
    var serverPublic = DiffieHellman.PublicKey(g, b, p);                       // B = g^b mod p
    var key = DiffieHellman.DeriveKey(DiffieHellman.SharedSecret(clientPublic, b, p)); // K = A^b mod p

    string id;
    do
    {
        id = Convert.ToHexString(RandomNumberGenerator.GetBytes(4)).ToLowerInvariant();
    } while (!sessions.TryAdd(id, new Session(id, key, DateTime.UtcNow)));

    return Results.Json(new JsonObject { ["session_id"] = id, ["B"] = DiffieHellman.ToHex(serverPublic) });
});

// ---------------------------------------------------------------- telemetry
app.MapPost("/api/telemetry", async (HttpRequest req) =>
{
    var failure = OpenEnvelope(await ReadBody(req), out var session, out var msg);
    if (failure != null) return failure;

    var bad = schemas.Validate("measure", msg);
    if (bad != null) return Fail(session, 400, bad.Field, bad.Message);

    var sensor = msg!["sensor_id"]!.GetValue<string>();
    SaveReading(sensor, msg);

    var ack = new JsonObject { ["status"] = "ok", ["sensor_id"] = sensor };
    var alarm = CheckAlarm(msg["cargo_type"]!.GetValue<string>(), msg["temperature_c"]!.GetValue<double>());
    if (alarm != null) ack["alarm"] = alarm;
    return Reply(session, 200, ack, "ack");
});

// ---------------------------------------------------------------- readings
app.MapPost("/api/readings", async (HttpRequest req) =>
{
    var failure = OpenEnvelope(await ReadBody(req), out var session, out var msg);
    if (failure != null) return failure;

    var bad = schemas.Validate("readings-request", msg);
    if (bad != null) return Fail(session, 400, bad.Field, bad.Message);

    var sensor = msg!["sensor_id"]!.GetValue<string>();   // gia' validato dal pattern: sicuro come nome file
    var from = ParseDate((string?)msg["from"]);
    var to = ParseDate((string?)msg["to"]);

    var found = new JsonArray();
    foreach (var item in LoadReadings(sensor))
    {
        var ts = ParseDate((string?)item!["timestamp"])!.Value;
        if ((from == null || ts >= from) && (to == null || ts <= to))
            found.Add(item.DeepClone());
    }

    var response = new JsonObject { ["sensor_id"] = sensor, ["count"] = found.Count, ["readings"] = found };
    return Reply(session, 200, response, "readings-response");
});

// ---------------------------------------------------------------- close
app.MapPost("/api/close", async (HttpRequest req) =>
{
    var failure = OpenEnvelope(await ReadBody(req), out var session, out var msg);
    if (failure != null) return failure;

    var bad = schemas.Validate("close-request", msg);
    if (bad != null) return Fail(session, 400, bad.Field, bad.Message);

    var result = Reply(session, 200, new JsonObject { ["status"] = "closed" }, "ack");
    sessions.TryRemove(session.Id, out _);   // la chiave viene cancellata
    return result;
});

app.Run();

// ================================================================ funzioni di supporto

static async Task<string> ReadBody(HttpRequest r)
{
    using var reader = new StreamReader(r.Body);
    return await reader.ReadToEndAsync();
}

static DateTimeOffset? ParseDate(string? s)
    => s == null ? null : DateTimeOffset.Parse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal);

// errore in chiaro: usato solo quando non c'e' (ancora) una chiave con cui cifrare
IResult Plain(int status, string field, string message) =>
    Results.Json(new JsonObject
    {
        ["error"] = status switch { 400 => "bad_request", 401 => "unauthorized", 404 => "not_found", _ => "error" },
        ["field"] = field,
        ["message"] = message,
    }, statusCode: status);

// risposta cifrata; controlla anche che la risposta rispetti lo schema
IResult Reply(Session s, int status, JsonNode payload, string schemaName)
{
    var problem = schemas.Validate(schemaName, payload);
    if (problem != null)
        throw new InvalidOperationException($"Risposta non conforme a {schemaName}: {problem.Field} {problem.Message}");
    return Results.Json(CryptoBox.Seal(s.Key, s.Id, payload.ToJsonString()), statusCode: status);
}

// errore cifrato (la decifratura e' gia' riuscita, quindi la chiave c'e')
IResult Fail(Session s, int status, string field, string message) =>
    Reply(s, status, new JsonObject
    {
        ["error"] = status == 400 ? "bad_request" : "error",
        ["field"] = field,
        ["message"] = message,
    }, "error");

// REGOLA DI SICUREZZA: prima si decifra, poi si valida. Se decifratura o tag falliscono -> 400.
IResult? OpenEnvelope(string body, out Session session, out JsonNode? message)
{
    session = null!;
    message = null;

    JsonNode? envelope;
    try { envelope = JsonNode.Parse(body); }
    catch (JsonException) { return Plain(400, "/", "JSON non valido"); }

    var bad = schemas.Validate("envelope", envelope);
    if (bad != null) return Plain(400, bad.Field, bad.Message);

    var id = envelope!["session_id"]!.GetValue<string>();
    if (!sessions.TryGetValue(id, out var found)) return Plain(404, "/session_id", "Sessione inesistente");
    if (DateTime.UtcNow - found.Created > sessionTtl)
    {
        sessions.TryRemove(id, out _);
        return Plain(401, "/session_id", "Sessione scaduta: rifare l'handshake");
    }

    string plain;
    try
    {
        plain = CryptoBox.Open(found.Key, new Envelope(id,
            envelope["ciphertext"]!.GetValue<string>(), envelope["tag"]!.GetValue<string>()));
    }
    catch (Exception ex) when (ex is CryptographicException or FormatException)
    {
        return Plain(400, "/tag", "Busta non valida: decifratura o tag falliti");
    }

    try { message = JsonNode.Parse(plain); }
    catch (JsonException) { return Fail(found, 400, "/", "JSON non valido"); }

    session = found;
    return null;
}

JsonObject? CheckAlarm(string cargo, double temperature)
{
    var (min, max) = safeRanges[cargo];
    if (temperature >= min && temperature <= max) return null;
    return new JsonObject
    {
        ["level"] = "critical",
        ["message"] = string.Create(CultureInfo.InvariantCulture,
            $"Temperatura {temperature} C fuori dall'intervallo [{min}, {max}] per merce '{cargo}'"),
    };
}

string ReadingsPath(string sensor) => Path.Combine(dataDir, $"{sensor}.json");

JsonArray LoadReadings(string sensor)
{
    lock (fileLock)
    {
        var path = ReadingsPath(sensor);
        return File.Exists(path) ? JsonNode.Parse(File.ReadAllText(path))!.AsArray() : new JsonArray();
    }
}

void SaveReading(string sensor, JsonNode reading)
{
    lock (fileLock)
    {
        var all = LoadReadings(sensor);
        all.Add(reading.DeepClone());
        File.WriteAllText(ReadingsPath(sensor), all.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
    }
}

record Session(string Id, byte[] Key, DateTime Created);

public partial class Program { }   // serve ai test (WebApplicationFactory)
