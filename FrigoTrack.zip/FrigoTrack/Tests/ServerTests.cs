using System.Net;
using System.Numerics;
using System.Text.Json.Nodes;
using FrigoTrack.Common;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace FrigoTrack.Tests;

public class ServerFactory : WebApplicationFactory<Program>
{
    public string DataDir { get; } = Path.Combine(Path.GetTempPath(), "frigotrack-tests-" + Guid.NewGuid());

    protected override void ConfigureWebHost(IWebHostBuilder builder) => builder.UseSetting("DataDir", DataDir);
}

public class ServerTests : IClassFixture<ServerFactory>
{
    private readonly ServerFactory _factory;
    private static readonly SchemaStore Schemas = new();

    public ServerTests(ServerFactory factory) => _factory = factory;

    private static JsonObject Measure(double temperature = 4.6, string cargo = "pharma") => new()
    {
        ["sensor_id"] = "CELLA-BG-007",
        ["timestamp"] = "2026-11-02T08:15:30Z",
        ["cargo_type"] = cargo,
        ["temperature_c"] = temperature,
        ["humidity"] = 55,
        ["battery"] = 87,
    };

    [Fact]
    public async Task Handshake_riuscito()
    {
        var channel = await SecureClient.ConnectAsync(_factory.CreateClient(), Schemas);
        Assert.Matches("^[0-9a-f]{8}$", channel.SessionId);
    }

    [Fact]
    public async Task Messaggio_valido_restituisce_200_e_ack_senza_allarme()
    {
        var channel = await SecureClient.ConnectAsync(_factory.CreateClient(), Schemas);
        var (status, body) = await channel.SendAsync("/api/telemetry", Measure(4.6), "measure");

        Assert.Equal(HttpStatusCode.OK, status);
        Assert.Equal("ok", body!["status"]!.GetValue<string>());
        Assert.Null(body["alarm"]);
    }

    [Fact]
    public async Task Temperatura_fuori_intervallo_genera_allarme()
    {
        var channel = await SecureClient.ConnectAsync(_factory.CreateClient(), Schemas);
        var (status, body) = await channel.SendAsync("/api/telemetry", Measure(12.0), "measure");

        Assert.Equal(HttpStatusCode.OK, status);
        Assert.NotNull(body!["alarm"]);
    }

    [Fact]
    public async Task Messaggio_non_valido_restituisce_400_con_il_campo_sbagliato()
    {
        // validateBeforeSend: false -> il messaggio sbagliato arriva davvero al server
        var channel = await SecureClient.ConnectAsync(_factory.CreateClient(), Schemas, validateBeforeSend: false);
        var (status, body) = await channel.SendAsync("/api/telemetry", Measure(99), "measure");

        Assert.Equal(HttpStatusCode.BadRequest, status);
        Assert.Equal("/temperature_c", body!["field"]!.GetValue<string>());
    }

    [Fact]
    public async Task Busta_manomessa_restituisce_400()
    {
        var channel = await SecureClient.ConnectAsync(_factory.CreateClient(), Schemas);
        var envelope = channel.Seal(Measure());

        var tag = Convert.FromBase64String(envelope.Tag);
        tag[0] ^= 0x01;   // basta cambiare un bit
        var tampered = envelope with { Tag = Convert.ToBase64String(tag) };

        var (status, _) = await channel.PostEnvelopeAsync("/api/telemetry", tampered);
        Assert.Equal(HttpStatusCode.BadRequest, status);
    }

    [Fact]
    public async Task Sessione_inesistente_restituisce_404()
    {
        var channel = await SecureClient.ConnectAsync(_factory.CreateClient(), Schemas);
        var fake = new Envelope("deadbeef", Convert.ToBase64String(new byte[28]), Convert.ToBase64String(new byte[16]));

        var (status, _) = await channel.PostEnvelopeAsync("/api/telemetry", fake);
        Assert.Equal(HttpStatusCode.NotFound, status);
    }

    [Fact]
    public void Entrambe_le_parti_ricavano_la_stessa_chiave()
    {
        var a = DiffieHellman.GeneratePrivate();
        var b = DiffieHellman.GeneratePrivate();
        var publicA = DiffieHellman.PublicKey(DiffieHellman.G, a, DiffieHellman.P);
        var publicB = DiffieHellman.PublicKey(DiffieHellman.G, b, DiffieHellman.P);

        Assert.Equal(
            DiffieHellman.DeriveKey(DiffieHellman.SharedSecret(publicB, a, DiffieHellman.P)),
            DiffieHellman.DeriveKey(DiffieHellman.SharedSecret(publicA, b, DiffieHellman.P)));
    }

    [Fact]
    public void Costante_p_e_corretta_test_di_Fermat()
    {
        // se ho sbagliato a ricopiare un solo carattere di p, questo test fallisce
        var p = DiffieHellman.P;
        Assert.Equal(BigInteger.One, BigInteger.ModPow(2, p - 1, p));
        Assert.Equal(BigInteger.One, BigInteger.ModPow(3, p - 1, p));
        Assert.Equal(2048, (int)p.GetBitLength());
    }
}
