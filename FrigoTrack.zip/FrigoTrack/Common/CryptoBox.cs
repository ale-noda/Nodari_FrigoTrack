using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Serialization;

namespace FrigoTrack.Common;

public sealed record Envelope(
    [property: JsonPropertyName("session_id")] string SessionId,
    [property: JsonPropertyName("ciphertext")] string Ciphertext,
    [property: JsonPropertyName("tag")] string Tag);

/// <summary>
/// Cifratura autenticata AES-256-GCM.
/// Il nonce (12 byte) viene messo davanti al ciphertext; il session_id e' usato come AAD,
/// cosi' una busta non puo' essere riusata con un altro session_id.
/// </summary>
public static class CryptoBox
{
    private const int NonceSize = 12;
    private const int TagSize = 16;

    public static Envelope Seal(byte[] key, string sessionId, string plaintext)
    {
        var nonce = RandomNumberGenerator.GetBytes(NonceSize);
        var data = Encoding.UTF8.GetBytes(plaintext);
        var cipher = new byte[data.Length];
        var tag = new byte[TagSize];

        using var gcm = new AesGcm(key, TagSize);
        gcm.Encrypt(nonce, data, cipher, tag, Encoding.UTF8.GetBytes(sessionId));

        return new Envelope(sessionId, Convert.ToBase64String(nonce.Concat(cipher).ToArray()), Convert.ToBase64String(tag));
    }

    /// <summary>Lancia CryptographicException o FormatException se la busta non e' valida.</summary>
    public static string Open(byte[] key, Envelope envelope)
    {
        var blob = Convert.FromBase64String(envelope.Ciphertext);
        var tag = Convert.FromBase64String(envelope.Tag);
        if (blob.Length < NonceSize || tag.Length != TagSize)
            throw new CryptographicException("Busta malformata");

        var nonce = blob[..NonceSize];
        var cipher = blob[NonceSize..];
        var plain = new byte[cipher.Length];

        using var gcm = new AesGcm(key, TagSize);
        gcm.Decrypt(nonce, cipher, tag, plain, Encoding.UTF8.GetBytes(envelope.SessionId));
        return Encoding.UTF8.GetString(plain);
    }
}
