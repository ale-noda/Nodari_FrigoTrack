using System.Globalization;
using System.Numerics;
using System.Security.Cryptography;

namespace FrigoTrack.Common;

/// <summary>
/// Scambio di chiavi Diffie-Hellman scritto a mano.
/// Si usa solo BigInteger.ModPow (potenza modulare), non librerie che eseguano lo scambio.
/// </summary>
public static class DiffieHellman
{
    // RFC 3526, gruppo 14 (MODP a 2048 bit), generatore 2.
    private const string PHex =
        "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
        "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
        "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
        "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
        "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D" +
        "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F" +
        "83655D23DCA3AD961C62F356208552BB9ED529077096966D" +
        "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
        "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9" +
        "DE2BCBF6955817183995497CEA956AE515D2261898FA0510" +
        "15728E5A8AACAA68FFFFFFFFFFFFFFFF";

    public static readonly BigInteger P = FromHex(PHex);
    public static readonly BigInteger G = 2;

    /// <summary>Segreto casuale a 256 bit (a per il client, b per il server).</summary>
    public static BigInteger GeneratePrivate()
    {
        BigInteger x;
        do
        {
            x = new BigInteger(RandomNumberGenerator.GetBytes(32), isUnsigned: true, isBigEndian: true);
        } while (x < 2);
        return x;
    }

    /// <summary>A = g^a mod p (oppure B = g^b mod p).</summary>
    public static BigInteger PublicKey(BigInteger g, BigInteger secret, BigInteger p)
        => BigInteger.ModPow(g, secret, p);

    /// <summary>K = B^a mod p (oppure A^b mod p).</summary>
    public static BigInteger SharedSecret(BigInteger peerPublic, BigInteger secret, BigInteger p)
        => BigInteger.ModPow(peerPublic, secret, p);

    /// <summary>Scarta i valori 0, 1 e p-1, che darebbero un segreto prevedibile.</summary>
    public static bool IsValidPublic(BigInteger x, BigInteger p) => x > 1 && x < p - 1;

    /// <summary>Chiave AES a 256 bit = SHA-256 del segreto condiviso K.</summary>
    public static byte[] DeriveKey(BigInteger k)
        => SHA256.HashData(k.ToByteArray(isUnsigned: true, isBigEndian: true));

    public static string ToHex(BigInteger x)
        => Convert.ToHexString(x.ToByteArray(isUnsigned: true, isBigEndian: true));

    public static BigInteger FromHex(string hex)
        => BigInteger.Parse("0" + hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
}
