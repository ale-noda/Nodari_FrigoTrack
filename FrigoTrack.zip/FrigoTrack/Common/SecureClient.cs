using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace FrigoTrack.Common;

/// <summary>Canale cifrato verso il server: fa l'handshake e poi invia messaggi in busta.</summary>
public sealed class SecureClient
{
    private readonly HttpClient _http;
    private readonly SchemaStore _schemas;
    private readonly byte[] _key;
    private readonly bool _validate;

    public string SessionId { get; }

    private SecureClient(HttpClient http, SchemaStore schemas, byte[] key, string sessionId, bool validate)
    {
        _http = http; _schemas = schemas; _key = key; SessionId = sessionId; _validate = validate;
    }

    public static async Task<SecureClient> ConnectAsync(HttpClient http, SchemaStore schemas, bool validateBeforeSend = true)
    {
        var p = DiffieHellman.P;
        var g = DiffieHellman.G;
        var a = DiffieHellman.GeneratePrivate();          // segreto, non lascia mai il client
        var publicA = DiffieHellman.PublicKey(g, a, p);   // A = g^a mod p

        var request = new JsonObject
        {
            ["p"] = DiffieHellman.ToHex(p),
            ["g"] = DiffieHellman.ToHex(g),
            ["A"] = DiffieHellman.ToHex(publicA),
        };
        var bad = schemas.Validate("handshake-request", request);
        if (bad != null) throw new SchemaException(bad);

        using var res = await http.PostAsync("/api/handshake", Json(request.ToJsonString()));
        var text = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException($"Handshake rifiutato ({(int)res.StatusCode}): {text}");

        var response = JsonNode.Parse(text);
        bad = schemas.Validate("handshake-response", response);
        if (bad != null) throw new SchemaException(bad);

        var publicB = DiffieHellman.FromHex(response!["B"]!.GetValue<string>());
        if (!DiffieHellman.IsValidPublic(publicB, p))
            throw new CryptographicException("Chiave pubblica del server non valida");

        var key = DiffieHellman.DeriveKey(DiffieHellman.SharedSecret(publicB, a, p)); // K = B^a mod p
        return new SecureClient(http, schemas, key, response["session_id"]!.GetValue<string>(), validateBeforeSend);
    }

    public Envelope Seal(JsonNode message) => CryptoBox.Seal(_key, SessionId, message.ToJsonString());

    /// <summary>Valida con lo schema, cifra, invia, decifra la risposta.</summary>
    public async Task<(HttpStatusCode Status, JsonNode? Body)> SendAsync(string path, JsonNode message, string schemaName)
    {
        if (_validate)
        {
            var bad = _schemas.Validate(schemaName, message);
            if (bad != null) throw new SchemaException(bad);
        }
        return await PostEnvelopeAsync(path, Seal(message));
    }

    public async Task<(HttpStatusCode Status, JsonNode? Body)> PostEnvelopeAsync(string path, Envelope envelope)
    {
        using var res = await _http.PostAsync(path, Json(JsonSerializer.Serialize(envelope)));
        var node = JsonNode.Parse(await res.Content.ReadAsStringAsync());

        // le risposte sono buste cifrate; gli errori "senza sessione" sono invece in chiaro
        if (node is JsonObject o && o.ContainsKey("ciphertext"))
        {
            var plain = CryptoBox.Open(_key, new Envelope(
                o["session_id"]!.GetValue<string>(), o["ciphertext"]!.GetValue<string>(), o["tag"]!.GetValue<string>()));
            node = JsonNode.Parse(plain);
        }
        return (res.StatusCode, node);
    }

    private static StringContent Json(string json) => new(json, Encoding.UTF8, "application/json");
}
