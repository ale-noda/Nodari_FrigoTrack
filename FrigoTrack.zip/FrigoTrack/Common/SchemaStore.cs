using System.Text.Json.Nodes;
using Json.Schema;

namespace FrigoTrack.Common;

public sealed record ValidationError(string Field, string Message);

public sealed class SchemaException(ValidationError error) : Exception($"{error.Field}: {error.Message}")
{
    public string Field => error.Field;
}

/// <summary>Carica tutti gli schemi dalla cartella schemas/ e valida i messaggi per nome file.</summary>
public sealed class SchemaStore
{
    private static readonly EvaluationOptions Options = new()
    {
        OutputFormat = OutputFormat.List,
        RequireFormatValidation = true, // fa rispettare anche "format": "date-time"
    };

    private readonly Dictionary<string, JsonSchema> _schemas = new();

    public SchemaStore(string? directory = null)
    {
        directory ??= FindSchemasDirectory();
        foreach (var file in Directory.GetFiles(directory, "*.json"))
            _schemas[Path.GetFileNameWithoutExtension(file)] = JsonSchema.FromFile(file);
    }

    /// <summary>Null se il messaggio e' valido, altrimenti il primo errore con il campo sbagliato.</summary>
    public ValidationError? Validate(string schemaName, JsonNode? instance)
    {
        var result = _schemas[schemaName].Evaluate(instance, Options);
        if (result.IsValid) return null;

        var bad = new[] { result }.Concat(result.Details).FirstOrDefault(n => n.Errors is { Count: > 0 });
        var field = bad?.InstanceLocation.ToString();
        if (string.IsNullOrEmpty(field)) field = "/";
        var message = bad?.Errors?.First().Value ?? "Messaggio non valido";
        return new ValidationError(field, message);
    }

    private static string FindSchemasDirectory()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null)
        {
            var candidate = Path.Combine(dir.FullName, "schemas");
            if (Directory.Exists(candidate)) return candidate;
            dir = dir.Parent;
        }
        throw new DirectoryNotFoundException("Cartella schemas/ non trovata");
    }
}
