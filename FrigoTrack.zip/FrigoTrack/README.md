# FrigoTrack - Telemetria sicura per la catena del freddo

Sistema client-server HTTP (C# / .NET 8) in cui sensori di temperatura inviano misure JSON
cifrate con una chiave concordata tramite Diffie-Hellman e validate con JSON Schema.

## Struttura

| Cartella | Contenuto |
|---|---|
| `Common/` | Diffie-Hellman (`DiffieHellman.cs`), cifratura AES-GCM (`CryptoBox.cs`), validazione (`SchemaStore.cs`), canale cifrato lato client (`SecureClient.cs`) |
| `Server/` | Server HTTP (ASP.NET Core minimal API) con i 4 endpoint |
| `Client/` | Simulatore di 3 sensori |
| `schemas/` | Un file JSON Schema per ogni tipo di messaggio |
| `Tests/` | Test xUnit |

## Avvio

Serve il .NET 8 SDK.

```bash
dotnet new sln -n FrigoTrack
dotnet sln add Common Server Client Tests

dotnet run --project Server --urls http://localhost:5000     # terminale 1
dotnet run --project Client                                  # terminale 2
dotnet test                                                  # test
```

Opzioni del client: `--count=5` `--interval-ms=2000` `http://host:porta`.

Demo di un messaggio non valido:

```bash
dotnet run --project Client -- --invalid                         # rifiutato dal client (validazione prima di cifrare)
dotnet run --project Client -- --invalid --bypass-validation     # arriva al server, che risponde 400
```

Le misure ricevute sono salvate in `data/<sensor_id>.json`.

## Handshake (diagramma di sequenza)

```mermaid
sequenceDiagram
    participant C as Client (sensore)
    participant S as Server
    C->>C: sceglie p, g (RFC 3526 gr.14) e segreto casuale a
    C->>S: POST /api/handshake {p, g, A = g^a mod p}  (in chiaro)
    S->>S: controlla p, g, A; sceglie b; B = g^b mod p; K = A^b mod p
    S->>S: genera session_id, salva chiave = SHA-256(K)
    S-->>C: {session_id, B}
    C->>C: K = B^a mod p; chiave = SHA-256(K)
    C->>S: POST /api/telemetry {session_id, ciphertext, tag}
    S->>S: decifra (AES-GCM) -> poi valida con JSON Schema
    S-->>C: busta cifrata {status, alarm?}
    C->>S: POST /api/close (busta cifrata)
    S-->>C: busta cifrata {status: closed}, chiave cancellata
```

## Messaggi

| Endpoint | Richiesta | Risposta | Schemi |
|---|---|---|---|
| `POST /api/handshake` | `{p, g, A}` (hex, in chiaro) | `{session_id, B}` | `handshake-request`, `handshake-response` |
| `POST /api/telemetry` | busta con la misura | busta con ack ed eventuale allarme | `envelope`, `measure`, `ack` |
| `POST /api/readings` | busta con `{sensor_id, from?, to?}` | busta con `{sensor_id, count, readings[]}` | `readings-request`, `readings-response` |
| `POST /api/close` | busta con `{action: "close"}` | busta con `{status: "closed"}` | `close-request`, `ack` |

Busta: `{session_id, ciphertext, tag}` in Base64. Il `ciphertext` contiene nonce (12 byte) + dati cifrati;
il `session_id` e' autenticato come dato associato (AAD) di AES-GCM.

Codici HTTP: `200` ok; `400` JSON/schema non validi, busta manomessa o decifratura fallita;
`401` sessione scaduta (1 ora); `404` sessione inesistente.
Gli errori dopo la decifratura sono cifrati e rispettano `schemas/error.json` (`error`, `field`, `message`).

Allarmi (intervalli di sicurezza): `food` 0..5 C, `pharma` 2..8 C, `frozen` -40..-18 C.

## Limiti noti

- Diffie-Hellman non e' autenticato: un attaccante che modifica il traffico (man-in-the-middle) puo' fare handshake con entrambi. Servirebbero firme o una chiave pre-condivisa per sensore.
- Gli errori per sessione inesistente o busta non decifrabile sono in chiaro (non c'e' una chiave per cifrarli); l'identificativo di sessione e' in chiaro per progetto.
- Il segreto condiviso passa da SHA-256; in produzione si userebbe HKDF.
- Nessuna protezione da replay: una busta valida puo' essere rinviata (servirebbe un contatore o un timestamp controllato).
- Sessioni in memoria (si perdono al riavvio), nessun limite di dimensione delle richieste, file JSON letti per intero a ogni scrittura.
- Lo schema `readings-response` ripete lo schema della misura invece di fare `$ref` a `measure.json`.
